﻿namespace Coppel
{


    partial class COPPELDataSet
    {
    }
}
