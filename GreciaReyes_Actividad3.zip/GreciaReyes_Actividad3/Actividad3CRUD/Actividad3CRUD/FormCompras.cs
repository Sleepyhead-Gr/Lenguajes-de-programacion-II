// ================================================
// FormCompras.cs  
// ================================================
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Actividad3CRUD
{
    public partial class FormCompras : Form
    {
        public FormCompras()
        {
            InitializeComponent();
            CargarComboBoxes();
        }

        private void CargarComboBoxes()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var daC = new SqlDataAdapter(
                        "SELECT dni, nombre + ' ' + apellidos AS nombre_completo FROM CLIENTES", conn);
                    var dtC = new DataTable(); daC.Fill(dtC);
                    cmbClientes.DataSource    = dtC;
                    cmbClientes.DisplayMember = "nombre_completo";
                    cmbClientes.ValueMember   = "dni";

                    var daP = new SqlDataAdapter(
                        "SELECT codigo, nombre + ' ($' + CAST(precio AS VARCHAR) + ')' AS nombre_precio FROM PRODUCTOS", conn);
                    var dtP = new DataTable(); daP.Fill(dtP);
                    cmbProductos.DataSource    = dtP;
                    cmbProductos.DisplayMember = "nombre_precio";
                    cmbProductos.ValueMember   = "codigo";
                }
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            if (cmbClientes.SelectedValue == null || cmbProductos.SelectedValue == null)
            { MessageBox.Show("Seleccione cliente y producto.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand(
                        "INSERT INTO COMPRAS (dniCliente, codProducto, fechaCompra) " +
                        "VALUES (@cli, @prod, @fecha)", conn);
                    cmd.Parameters.AddWithValue("@cli",   (int)cmbClientes.SelectedValue);
                    cmd.Parameters.AddWithValue("@prod",  (int)cmbProductos.SelectedValue);
                    cmd.Parameters.AddWithValue("@fecha",
                        DateTime.TryParse(txtFecha.Text, out DateTime f) ? f : DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("La compra fue registrada exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            { MessageBox.Show("Seleccione una compra de la tabla.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand(
                        "UPDATE COMPRAS SET dniCliente=@cli, codProducto=@prod, " +
                        "fechaCompra=@fecha WHERE id=@id", conn);
                    cmd.Parameters.AddWithValue("@id",    int.Parse(txtId.Text));
                    cmd.Parameters.AddWithValue("@cli",   (int)cmbClientes.SelectedValue);
                    cmd.Parameters.AddWithValue("@prod",  (int)cmbProductos.SelectedValue);
                    cmd.Parameters.AddWithValue("@fecha",
                        DateTime.TryParse(txtFecha.Text, out DateTime f) ? f : DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("La compra fue modificada exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtId.Text))
            { MessageBox.Show("Seleccione una compra de la tabla.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (MessageBox.Show("¿Eliminar esta compra?", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand("DELETE FROM COMPRAS WHERE id=@id", conn);
                    cmd.Parameters.AddWithValue("@id", int.Parse(txtId.Text));
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("La compra fue eliminada exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnMostrar_Click(object sender, EventArgs e) => MostrarDatos();
        private void BtnRegresar_Click(object sender, EventArgs e) => this.Close();

        private void MostrarDatos()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var da = new SqlDataAdapter(
                        "SELECT c.id AS [ID], cl.nombre + ' ' + cl.apellidos AS [Cliente], " +
                        "p.nombre AS [Producto], p.precio AS [Precio], " +
                        "CONVERT(varchar, c.fechaCompra, 23) AS [Fecha] " +
                        "FROM COMPRAS c " +
                        "INNER JOIN CLIENTES cl ON c.dniCliente = cl.dni " +
                        "INNER JOIN PRODUCTOS p ON c.codProducto = p.codigo", conn);
                    var dt = new DataTable(); da.Fill(dt);
                    dgvCompras.DataSource = dt;
                }
            }
            catch (Exception ex) { Error(ex); }
        }

        private void DgvCompras_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var row = dgvCompras.Rows[e.RowIndex];
            txtId.Text    = row.Cells[0].Value?.ToString();
            txtFecha.Text = row.Cells[4].Value?.ToString();
        }

        private void Limpiar() { txtId.Text = ""; txtFecha.Text = DateTime.Now.ToString("yyyy-MM-dd"); }
        private void Error(Exception ex) =>
            MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
