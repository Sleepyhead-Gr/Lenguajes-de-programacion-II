// ================================================
// FormPassword.cs 
// Contraseña: admin123
// ================================================
using System;
using System.Windows.Forms;

namespace Actividad3CRUD
{
    public partial class FormPassword : Form
    {
        private const string CONTRASENA_CORRECTA = "admin123";

        public FormPassword()
        {
            InitializeComponent();
        }

        private void BtnAceptar_Click(object sender, EventArgs e) => Verificar();

        private void TxtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) Verificar();
        }

        private void Verificar()
        {
            if (txtPassword.Text == CONTRASENA_CORRECTA)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                lblMensaje.Text = "Contraseña incorrecta. Intente de nuevo.";
                txtPassword.Clear();
                txtPassword.Focus();
            }
        }
    }
}
