// ================================================
// FormCliente.cs 
// ================================================
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Actividad3CRUD
{
    public partial class FormCliente : Form
    {
        public FormCliente()
        {
            InitializeComponent();
            txtFechaNac.Text      = "AAAA-MM-DD";
            txtFechaNac.ForeColor = Color.Gray;
        }

        // ── Placeholder fecha ───────────────────────────
        private void TxtFechaNac_GotFocus(object sender, EventArgs e)
        {
            if (txtFechaNac.Text == "AAAA-MM-DD")
            { txtFechaNac.Text = ""; txtFechaNac.ForeColor = Color.Black; }
        }
        private void TxtFechaNac_LostFocus(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtFechaNac.Text))
            { txtFechaNac.Text = "AAAA-MM-DD"; txtFechaNac.ForeColor = Color.Gray; }
        }

        // ── AGREGAR ─────────────────────────────────────
        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos()) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand(
                        "INSERT INTO CLIENTES (nombre, apellidos, fechaNac, tfno) " +
                        "VALUES (@nombre, @apellidos, @fechaNac, @tfno)", conn);
                    cmd.Parameters.AddWithValue("@nombre",    txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@apellidos", txtApellidos.Text.Trim());
                    cmd.Parameters.AddWithValue("@fechaNac",  ObtenerFecha());
                    cmd.Parameters.AddWithValue("@tfno",      txtTfno.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("El cliente fue agregado exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        // ── MODIFICAR ───────────────────────────────────
        private void BtnModificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtDni.Text))
            { MessageBox.Show("Seleccione un cliente de la tabla.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!ValidarCampos()) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand(
                        "UPDATE CLIENTES SET nombre=@nombre, apellidos=@apellidos, " +
                        "fechaNac=@fechaNac, tfno=@tfno WHERE dni=@dni", conn);
                    cmd.Parameters.AddWithValue("@dni",       int.Parse(txtDni.Text));
                    cmd.Parameters.AddWithValue("@nombre",    txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@apellidos", txtApellidos.Text.Trim());
                    cmd.Parameters.AddWithValue("@fechaNac",  ObtenerFecha());
                    cmd.Parameters.AddWithValue("@tfno",      txtTfno.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("El cliente fue modificado exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        // ── ELIMINAR ────────────────────────────────────
        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtDni.Text))
            { MessageBox.Show("Seleccione un cliente de la tabla.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (MessageBox.Show("¿Eliminar este cliente?", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand("DELETE FROM CLIENTES WHERE dni=@dni", conn);
                    cmd.Parameters.AddWithValue("@dni", int.Parse(txtDni.Text));
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("El cliente fue eliminado exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        // ── MOSTRAR ─────────────────────────────────────
        private void BtnMostrar_Click(object sender, EventArgs e) => MostrarDatos();

        private void MostrarDatos()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var da = new SqlDataAdapter(
                        "SELECT dni AS [ID], nombre AS [Nombre], apellidos AS [Apellidos], " +
                        "CONVERT(varchar,fechaNac,23) AS [Fecha Nac.], tfno AS [Teléfono] " +
                        "FROM CLIENTES", conn);
                    var dt = new DataTable();
                    da.Fill(dt);
                    dgvClientes.DataSource = dt;
                }
            }
            catch (Exception ex) { Error(ex); }
        }

        // ── REGRESAR ────────────────────────────────────
        private void BtnRegresar_Click(object sender, EventArgs e) => this.Close();

        // ── Seleccionar fila del grid ───────────────────
        private void DgvClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var row = dgvClientes.Rows[e.RowIndex];
            txtDni.Text       = row.Cells[0].Value?.ToString();
            txtNombre.Text    = row.Cells[1].Value?.ToString();
            txtApellidos.Text = row.Cells[2].Value?.ToString();
            txtFechaNac.Text  = row.Cells[3].Value?.ToString() ?? "";
            txtFechaNac.ForeColor = Color.Black;
            txtTfno.Text      = row.Cells[4].Value?.ToString();
        }

        // ── Helpers ─────────────────────────────────────
        private bool ValidarCampos()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) ||
                string.IsNullOrWhiteSpace(txtApellidos.Text))
            {
                MessageBox.Show("Nombre y Apellidos son obligatorios.", "Validación",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        private object ObtenerFecha()
        {
            if (string.IsNullOrEmpty(txtFechaNac.Text) || txtFechaNac.Text == "AAAA-MM-DD")
                return System.DBNull.Value;
            if (DateTime.TryParse(txtFechaNac.Text, out DateTime d)) return d;
            return System.DBNull.Value;
        }
        private void Limpiar()
        {
            txtDni.Text = txtNombre.Text = txtApellidos.Text = txtTfno.Text = "";
            txtFechaNac.Text = "AAAA-MM-DD"; txtFechaNac.ForeColor = Color.Gray;
        }
        private void Error(Exception ex) =>
            MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
