// ================================================
// FormProveedor.cs  
// ================================================
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Actividad3CRUD
{
    public partial class FormProveedor : Form
    {
        public FormProveedor()
        {
            InitializeComponent();
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            if (!Validar()) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand(
                        "INSERT INTO PROVEEDORES (nombre, direccion) VALUES (@nombre, @dir)", conn);
                    cmd.Parameters.AddWithValue("@nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@dir",    txtDireccion.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("El proveedor fue agregado exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNif.Text))
            { MessageBox.Show("Seleccione un proveedor de la tabla.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!Validar()) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand(
                        "UPDATE PROVEEDORES SET nombre=@nombre, direccion=@dir WHERE nif=@nif", conn);
                    cmd.Parameters.AddWithValue("@nif",    int.Parse(txtNif.Text));
                    cmd.Parameters.AddWithValue("@nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@dir",    txtDireccion.Text.Trim());
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("El proveedor fue modificado exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNif.Text))
            { MessageBox.Show("Seleccione un proveedor de la tabla.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (MessageBox.Show("¿Eliminar este proveedor?", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand("DELETE FROM PROVEEDORES WHERE nif=@nif", conn);
                    cmd.Parameters.AddWithValue("@nif", int.Parse(txtNif.Text));
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("El proveedor fue eliminado exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnMostrar_Click(object sender, EventArgs e) => MostrarDatos();
        private void BtnRegresar_Click(object sender, EventArgs e) => this.Close();

        private void MostrarDatos()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var da = new SqlDataAdapter(
                        "SELECT nif AS [ID], nombre AS [Nombre], " +
                        "direccion AS [Dirección] FROM PROVEEDORES", conn);
                    var dt = new DataTable();
                    da.Fill(dt);
                    dgvProveedores.DataSource = dt;
                }
            }
            catch (Exception ex) { Error(ex); }
        }

        private void DgvProveedores_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var row = dgvProveedores.Rows[e.RowIndex];
            txtNif.Text       = row.Cells[0].Value?.ToString();
            txtNombre.Text    = row.Cells[1].Value?.ToString();
            txtDireccion.Text = row.Cells[2].Value?.ToString();
        }

        private bool Validar()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            { MessageBox.Show("El nombre es obligatorio.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            return true;
        }
        private void Limpiar() { txtNif.Text = txtNombre.Text = txtDireccion.Text = ""; }
        private void Error(Exception ex) =>
            MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
