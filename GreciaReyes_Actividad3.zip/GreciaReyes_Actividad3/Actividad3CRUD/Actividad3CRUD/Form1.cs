// ================================================
// Form1.cs  
// ================================================
using System;
using System.Windows.Forms;

namespace Actividad3CRUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // ── Bienvenida ─────────────────────────────────
        private void MnuMensajeBienvenida_Click(object sender, EventArgs e)
        {
            new FormBienvenida("Mensaje de Bienvenida",
                "Bienvenido a la tienda en línea ZAPATERÍA UMI,\n" +
                "donde podrá encontrar todo lo que usted necesita\n" +
                "y si no lo encuentra se lo conseguimos.\n" +
                "Somos su mejor opción hoy y siempre.").ShowDialog();
        }

        private void MnuQuienesSomos_Click(object sender, EventArgs e)
        {
            new FormBienvenida("¿Quiénes Somos?",
                "Somos una empresa mexicana que trata de apoyar\n" +
                "al comercio mexicano. Todos nuestros productos son\n" +
                "100% mexicanos, porque creemos en nosotros\n" +
                "y porque sabemos que podemos.").ShowDialog();
        }

        private void MnuMision_Click(object sender, EventArgs e)
        {
            new FormBienvenida("Misión",
                "MISIÓN:\nNuestra misión es darnos a conocer a nivel nacional\n" +
                "y lograr el objetivo de que todos los mexicanos\n" +
                "utilicen productos mexicanos, que abramos los ojos\n" +
                "y veamos que no por que el producto sea de otro país,\n" +
                "significa que es mejor.").ShowDialog();
        }

        private void MnuVision_Click(object sender, EventArgs e)
        {
            new FormBienvenida("Visión",
                "VISIÓN:\nNuestra visión es que una vez que nos encontremos\n" +
                "a nivel nacional, buscaremos el mercado internacional\n" +
                "y llevaremos el nombre de nuestro producto,\n" +
                "de nuestro país, a todo el mundo para que sepan\n" +
                "de lo que somos capaces.").ShowDialog();
        }

        // ── Productos ──────────────────────────────────
        private void MnuDamas_Click(object sender, EventArgs e)      => new FormProductosDamas().ShowDialog();
        private void MnuCaballeros_Click(object sender, EventArgs e)  => new FormProductosCaballeros().ShowDialog();

        // ── Registro (con contraseña) ───────────────────
        private void MnuCliente_Click(object sender, EventArgs e)    => AbrirConContrasena(() => new FormCliente().ShowDialog());
        private void MnuProveedor_Click(object sender, EventArgs e)  => AbrirConContrasena(() => new FormProveedor().ShowDialog());
        private void MnuProductoReg_Click(object sender, EventArgs e)=> AbrirConContrasena(() => new FormProducto().ShowDialog());

        // ── Compras ────────────────────────────────────
        private void MnuCompras_Click(object sender, EventArgs e)    => new FormCompras().ShowDialog();

        // ── Salir ──────────────────────────────────────
        private void MnuSalir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea salir de la aplicación?", "Salir",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Application.Exit();
        }

        // ── Helper contraseña ──────────────────────────
        private void AbrirConContrasena(Action accion)
        {
            using (var fp = new FormPassword())
            {
                if (fp.ShowDialog() == DialogResult.OK)
                    accion();
                else
                    MessageBox.Show("Contraseña incorrecta. Acceso denegado.",
                        "Acceso denegado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
