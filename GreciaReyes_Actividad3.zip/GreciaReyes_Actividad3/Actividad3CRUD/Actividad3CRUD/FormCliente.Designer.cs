// ================================================
// FormCliente.Designer.cs
// ================================================
namespace Actividad3CRUD
{
    partial class FormCliente
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlHeader    = new System.Windows.Forms.Panel();
            this.lblTitulo    = new System.Windows.Forms.Label();
            this.grpDatos     = new System.Windows.Forms.GroupBox();
            this.lblDni       = new System.Windows.Forms.Label();
            this.txtDni       = new System.Windows.Forms.TextBox();
            this.lblNombre    = new System.Windows.Forms.Label();
            this.txtNombre    = new System.Windows.Forms.TextBox();
            this.lblApellidos = new System.Windows.Forms.Label();
            this.txtApellidos = new System.Windows.Forms.TextBox();
            this.lblFechaNac  = new System.Windows.Forms.Label();
            this.txtFechaNac  = new System.Windows.Forms.TextBox();
            this.lblTfno      = new System.Windows.Forms.Label();
            this.txtTfno      = new System.Windows.Forms.TextBox();
            this.btnAgregar   = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnEliminar  = new System.Windows.Forms.Button();
            this.btnMostrar   = new System.Windows.Forms.Button();
            this.btnRegresar  = new System.Windows.Forms.Button();
            this.dgvClientes  = new System.Windows.Forms.DataGridView();
            this.pnlHeader.SuspendLayout();
            this.grpDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).BeginInit();
            this.SuspendLayout();

            // ── pnlHeader ───────────────────────────────
            this.pnlHeader.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlHeader.Controls.Add(this.lblTitulo);
            this.pnlHeader.Dock     = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Location = new System.Drawing.Point(0, 0);
            this.pnlHeader.Name     = "pnlHeader";
            this.pnlHeader.Size     = new System.Drawing.Size(820, 45);
            this.pnlHeader.TabIndex = 0;

            // lblTitulo
            this.lblTitulo.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.lblTitulo.Font      = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location  = new System.Drawing.Point(0, 0);
            this.lblTitulo.Name      = "lblTitulo";
            this.lblTitulo.Size      = new System.Drawing.Size(820, 45);
            this.lblTitulo.TabIndex  = 0;
            this.lblTitulo.Text      = "REGISTRO CLIENTE";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // ── grpDatos ────────────────────────────────
            this.grpDatos.Controls.Add(this.lblDni);
            this.grpDatos.Controls.Add(this.txtDni);
            this.grpDatos.Controls.Add(this.lblNombre);
            this.grpDatos.Controls.Add(this.txtNombre);
            this.grpDatos.Controls.Add(this.lblApellidos);
            this.grpDatos.Controls.Add(this.txtApellidos);
            this.grpDatos.Controls.Add(this.lblFechaNac);
            this.grpDatos.Controls.Add(this.txtFechaNac);
            this.grpDatos.Controls.Add(this.lblTfno);
            this.grpDatos.Controls.Add(this.txtTfno);
            this.grpDatos.Font     = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpDatos.Location = new System.Drawing.Point(15, 55);
            this.grpDatos.Name     = "grpDatos";
            this.grpDatos.Size     = new System.Drawing.Size(390, 195);
            this.grpDatos.TabIndex = 1;
            this.grpDatos.TabStop  = false;
            this.grpDatos.Text     = "Datos personales:";

            // lblDni / txtDni
            this.lblDni.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblDni.Location = new System.Drawing.Point(10, 28); this.lblDni.Name = "lblDni";
            this.lblDni.Size = new System.Drawing.Size(115, 22); this.lblDni.TabIndex = 0; this.lblDni.Text = "DNI (ID):";
            this.txtDni.BackColor = System.Drawing.Color.LightGray;
            this.txtDni.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDni.Location = new System.Drawing.Point(130, 25); this.txtDni.Name = "txtDni";
            this.txtDni.ReadOnly = true; this.txtDni.Size = new System.Drawing.Size(245, 23); this.txtDni.TabIndex = 1;

            // lblNombre / txtNombre
            this.lblNombre.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblNombre.Location = new System.Drawing.Point(10, 63); this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(115, 22); this.lblNombre.TabIndex = 2; this.lblNombre.Text = "Nombre(s):";
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNombre.Location = new System.Drawing.Point(130, 60); this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(245, 23); this.txtNombre.TabIndex = 3;

            // lblApellidos / txtApellidos
            this.lblApellidos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblApellidos.Location = new System.Drawing.Point(10, 98); this.lblApellidos.Name = "lblApellidos";
            this.lblApellidos.Size = new System.Drawing.Size(115, 22); this.lblApellidos.TabIndex = 4; this.lblApellidos.Text = "Apellido(s):";
            this.txtApellidos.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtApellidos.Location = new System.Drawing.Point(130, 95); this.txtApellidos.Name = "txtApellidos";
            this.txtApellidos.Size = new System.Drawing.Size(245, 23); this.txtApellidos.TabIndex = 5;

            // lblFechaNac / txtFechaNac
            this.lblFechaNac.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblFechaNac.Location = new System.Drawing.Point(10, 133); this.lblFechaNac.Name = "lblFechaNac";
            this.lblFechaNac.Size = new System.Drawing.Size(115, 22); this.lblFechaNac.TabIndex = 6; this.lblFechaNac.Text = "Fecha Nacimiento:";
            this.txtFechaNac.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtFechaNac.Location = new System.Drawing.Point(130, 130); this.txtFechaNac.Name = "txtFechaNac";
            this.txtFechaNac.Size = new System.Drawing.Size(245, 23); this.txtFechaNac.TabIndex = 7;
            this.txtFechaNac.GotFocus  += new System.EventHandler(this.TxtFechaNac_GotFocus);
            this.txtFechaNac.LostFocus += new System.EventHandler(this.TxtFechaNac_LostFocus);

            // lblTfno / txtTfno
            this.lblTfno.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblTfno.Location = new System.Drawing.Point(10, 168); this.lblTfno.Name = "lblTfno";
            this.lblTfno.Size = new System.Drawing.Size(115, 22); this.lblTfno.TabIndex = 8; this.lblTfno.Text = "Teléfono:";
            this.txtTfno.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTfno.Location = new System.Drawing.Point(130, 165); this.txtTfno.Name = "txtTfno";
            this.txtTfno.Size = new System.Drawing.Size(245, 23); this.txtTfno.TabIndex = 9;

            // ── Botones ──────────────────────────────────
            // btnAgregar
            this.btnAgregar.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font      = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnAgregar.ForeColor = System.Drawing.Color.White;
            this.btnAgregar.Location  = new System.Drawing.Point(420, 65);
            this.btnAgregar.Name      = "btnAgregar"; this.btnAgregar.Size = new System.Drawing.Size(140, 35);
            this.btnAgregar.TabIndex  = 10; this.btnAgregar.Text = "AGREGAR";
            this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);

            // btnModificar
            this.btnModificar.BackColor = System.Drawing.Color.SeaGreen;
            this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.Font      = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnModificar.ForeColor = System.Drawing.Color.White;
            this.btnModificar.Location  = new System.Drawing.Point(420, 110);
            this.btnModificar.Name      = "btnModificar"; this.btnModificar.Size = new System.Drawing.Size(140, 35);
            this.btnModificar.TabIndex  = 11; this.btnModificar.Text = "MODIFICAR";
            this.btnModificar.UseVisualStyleBackColor = false;
            this.btnModificar.Click += new System.EventHandler(this.BtnModificar_Click);

            // btnEliminar
            this.btnEliminar.BackColor = System.Drawing.Color.Tomato;
            this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font      = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnEliminar.ForeColor = System.Drawing.Color.White;
            this.btnEliminar.Location  = new System.Drawing.Point(570, 110);
            this.btnEliminar.Name      = "btnEliminar"; this.btnEliminar.Size = new System.Drawing.Size(140, 35);
            this.btnEliminar.TabIndex  = 12; this.btnEliminar.Text = "ELIMINAR";
            this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);

            // btnMostrar  (ancho doble)
            this.btnMostrar.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnMostrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMostrar.Font      = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnMostrar.ForeColor = System.Drawing.Color.White;
            this.btnMostrar.Location  = new System.Drawing.Point(420, 155);
            this.btnMostrar.Name      = "btnMostrar"; this.btnMostrar.Size = new System.Drawing.Size(290, 35);
            this.btnMostrar.TabIndex  = 13; this.btnMostrar.Text = "MOSTRAR";
            this.btnMostrar.UseVisualStyleBackColor = false;
            this.btnMostrar.Click += new System.EventHandler(this.BtnMostrar_Click);

            // btnRegresar
            this.btnRegresar.BackColor = System.Drawing.Color.SlateGray;
            this.btnRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegresar.Font      = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnRegresar.ForeColor = System.Drawing.Color.White;
            this.btnRegresar.Location  = new System.Drawing.Point(420, 200);
            this.btnRegresar.Name      = "btnRegresar"; this.btnRegresar.Size = new System.Drawing.Size(140, 35);
            this.btnRegresar.TabIndex  = 14; this.btnRegresar.Text = "REGRESAR";
            this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);

            // ── dgvClientes ──────────────────────────────
            this.dgvClientes.AllowUserToAddRows  = false;
            this.dgvClientes.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvClientes.BackgroundColor     = System.Drawing.Color.WhiteSmoke;
            this.dgvClientes.Location            = new System.Drawing.Point(15, 260);
            this.dgvClientes.Name                = "dgvClientes";
            this.dgvClientes.ReadOnly            = true;
            this.dgvClientes.SelectionMode       = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvClientes.Size                = new System.Drawing.Size(775, 255);
            this.dgvClientes.TabIndex            = 15;
            this.dgvClientes.CellClick          += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvClientes_CellClick);

            // ── FormCliente ──────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor           = System.Drawing.Color.White;
            this.ClientSize          = new System.Drawing.Size(820, 535);
            this.Controls.Add(this.dgvClientes);
            this.Controls.Add(this.btnRegresar);
            this.Controls.Add(this.btnMostrar);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnModificar);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.grpDatos);
            this.Controls.Add(this.pnlHeader);
            this.Name          = "FormCliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text          = "Registro de Clientes";
            this.pnlHeader.ResumeLayout(false);
            this.grpDatos.ResumeLayout(false);
            this.grpDatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvClientes)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel          pnlHeader;
        private System.Windows.Forms.Label          lblTitulo;
        private System.Windows.Forms.GroupBox       grpDatos;
        private System.Windows.Forms.Label          lblDni;
        private System.Windows.Forms.TextBox        txtDni;
        private System.Windows.Forms.Label          lblNombre;
        private System.Windows.Forms.TextBox        txtNombre;
        private System.Windows.Forms.Label          lblApellidos;
        private System.Windows.Forms.TextBox        txtApellidos;
        private System.Windows.Forms.Label          lblFechaNac;
        private System.Windows.Forms.TextBox        txtFechaNac;
        private System.Windows.Forms.Label          lblTfno;
        private System.Windows.Forms.TextBox        txtTfno;
        private System.Windows.Forms.Button         btnAgregar;
        private System.Windows.Forms.Button         btnModificar;
        private System.Windows.Forms.Button         btnEliminar;
        private System.Windows.Forms.Button         btnMostrar;
        private System.Windows.Forms.Button         btnRegresar;
        private System.Windows.Forms.DataGridView   dgvClientes;
    }
}
