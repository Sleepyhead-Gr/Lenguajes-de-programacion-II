// ================================================
// FormProducto.cs 
// ================================================
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Actividad3CRUD
{
    public partial class FormProducto : Form
    {
        public FormProducto()
        {
            InitializeComponent();
        }

        private void BtnAgregar_Click(object sender, EventArgs e)
        {
            if (!Validar()) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand(
                        "INSERT INTO PRODUCTOS (nombre, precio, nifProveedor) " +
                        "VALUES (@nombre, @precio, @nif)", conn);
                    cmd.Parameters.AddWithValue("@nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@precio", decimal.Parse(txtPrecio.Text));
                    cmd.Parameters.AddWithValue("@nif",
                        string.IsNullOrWhiteSpace(txtNifProveedor.Text) ?
                        (object)System.DBNull.Value : int.Parse(txtNifProveedor.Text));
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("El producto fue agregado exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnModificar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCodigo.Text))
            { MessageBox.Show("Seleccione un producto de la tabla.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!Validar()) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand(
                        "UPDATE PRODUCTOS SET nombre=@nombre, precio=@precio, " +
                        "nifProveedor=@nif WHERE codigo=@codigo", conn);
                    cmd.Parameters.AddWithValue("@codigo", int.Parse(txtCodigo.Text));
                    cmd.Parameters.AddWithValue("@nombre", txtNombre.Text.Trim());
                    cmd.Parameters.AddWithValue("@precio", decimal.Parse(txtPrecio.Text));
                    cmd.Parameters.AddWithValue("@nif",
                        string.IsNullOrWhiteSpace(txtNifProveedor.Text) ?
                        (object)System.DBNull.Value : int.Parse(txtNifProveedor.Text));
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("El producto fue modificado exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCodigo.Text))
            { MessageBox.Show("Seleccione un producto de la tabla.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (MessageBox.Show("¿Eliminar este producto?", "Confirmar",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var cmd = new SqlCommand("DELETE FROM PRODUCTOS WHERE codigo=@codigo", conn);
                    cmd.Parameters.AddWithValue("@codigo", int.Parse(txtCodigo.Text));
                    cmd.ExecuteNonQuery();
                }
                MessageBox.Show("El producto fue eliminado exitosamente.", "Éxito",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                Limpiar(); MostrarDatos();
            }
            catch (Exception ex) { Error(ex); }
        }

        private void BtnMostrar_Click(object sender, EventArgs e) => MostrarDatos();
        private void BtnRegresar_Click(object sender, EventArgs e) => this.Close();

        private void MostrarDatos()
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    var da = new SqlDataAdapter(
                        "SELECT p.codigo AS [ID], p.nombre AS [Nombre], " +
                        "p.precio AS [Precio], pr.nombre AS [Proveedor] " +
                        "FROM PRODUCTOS p LEFT JOIN PROVEEDORES pr " +
                        "ON p.nifProveedor = pr.nif", conn);
                    var dt = new DataTable();
                    da.Fill(dt);
                    dgvProductos.DataSource = dt;
                }
            }
            catch (Exception ex) { Error(ex); }
        }

        private void DgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var row = dgvProductos.Rows[e.RowIndex];
            txtCodigo.Text      = row.Cells[0].Value?.ToString();
            txtNombre.Text      = row.Cells[1].Value?.ToString();
            txtPrecio.Text      = row.Cells[2].Value?.ToString();
            txtNifProveedor.Text= "";
        }

        private bool Validar()
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
            { MessageBox.Show("El nombre es obligatorio.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            if (!decimal.TryParse(txtPrecio.Text, out _))
            { MessageBox.Show("Ingrese un precio numérico válido.", "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning); return false; }
            return true;
        }
        private void Limpiar() { txtCodigo.Text = txtNombre.Text = txtPrecio.Text = txtNifProveedor.Text = ""; }
        private void Error(Exception ex) =>
            MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
