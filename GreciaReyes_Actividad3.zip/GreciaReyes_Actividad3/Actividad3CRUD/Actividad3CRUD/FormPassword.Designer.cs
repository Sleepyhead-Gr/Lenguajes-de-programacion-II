// ================================================
// FormPassword.Designer.cs
// ================================================
namespace Actividad3CRUD
{
    partial class FormPassword
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblIcono     = new System.Windows.Forms.Label();
            this.lblTitulo    = new System.Windows.Forms.Label();
            this.txtPassword  = new System.Windows.Forms.TextBox();
            this.lblMensaje   = new System.Windows.Forms.Label();
            this.btnAceptar   = new System.Windows.Forms.Button();
            this.btnCancelar  = new System.Windows.Forms.Button();
            this.SuspendLayout();

            // lblIcono
            this.lblIcono.Font      = new System.Drawing.Font("Segoe UI", 20F);
            this.lblIcono.Location  = new System.Drawing.Point(155, 10);
            this.lblIcono.Name      = "lblIcono";
            this.lblIcono.Size      = new System.Drawing.Size(50, 40);
            this.lblIcono.TabIndex  = 0;
            this.lblIcono.Text      = "🔒";
            this.lblIcono.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // lblTitulo
            this.lblTitulo.Font      = new System.Drawing.Font("Segoe UI", 10F);
            this.lblTitulo.Location  = new System.Drawing.Point(20, 55);
            this.lblTitulo.Name      = "lblTitulo";
            this.lblTitulo.Size      = new System.Drawing.Size(340, 22);
            this.lblTitulo.TabIndex  = 1;
            this.lblTitulo.Text      = "Ingrese la contraseña de acceso:";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // txtPassword
            this.txtPassword.Font         = new System.Drawing.Font("Segoe UI", 10F);
            this.txtPassword.Location     = new System.Drawing.Point(80, 82);
            this.txtPassword.Name         = "txtPassword";
            this.txtPassword.PasswordChar = '●';
            this.txtPassword.Size         = new System.Drawing.Size(210, 25);
            this.txtPassword.TabIndex     = 2;
            this.txtPassword.KeyDown     += new System.Windows.Forms.KeyEventHandler(this.TxtPassword_KeyDown);

            // lblMensaje
            this.lblMensaje.Font      = new System.Drawing.Font("Segoe UI", 8F);
            this.lblMensaje.ForeColor = System.Drawing.Color.Red;
            this.lblMensaje.Location  = new System.Drawing.Point(80, 110);
            this.lblMensaje.Name      = "lblMensaje";
            this.lblMensaje.Size      = new System.Drawing.Size(210, 18);
            this.lblMensaje.TabIndex  = 3;
            this.lblMensaje.Text      = "";
            this.lblMensaje.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // btnAceptar
            this.btnAceptar.BackColor            = System.Drawing.Color.SeaGreen;
            this.btnAceptar.FlatStyle            = System.Windows.Forms.FlatStyle.Flat;
            this.btnAceptar.Font                 = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnAceptar.ForeColor            = System.Drawing.Color.White;
            this.btnAceptar.Location             = new System.Drawing.Point(80, 133);
            this.btnAceptar.Name                 = "btnAceptar";
            this.btnAceptar.Size                 = new System.Drawing.Size(95, 32);
            this.btnAceptar.TabIndex             = 4;
            this.btnAceptar.Text                 = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = false;
            this.btnAceptar.Click               += new System.EventHandler(this.BtnAceptar_Click);

            // btnCancelar
            this.btnCancelar.BackColor            = System.Drawing.Color.Tomato;
            this.btnCancelar.DialogResult         = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancelar.FlatStyle            = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancelar.Font                 = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnCancelar.ForeColor            = System.Drawing.Color.White;
            this.btnCancelar.Location             = new System.Drawing.Point(195, 133);
            this.btnCancelar.Name                 = "btnCancelar";
            this.btnCancelar.Size                 = new System.Drawing.Size(95, 32);
            this.btnCancelar.TabIndex             = 5;
            this.btnCancelar.Text                 = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;

            // FormPassword
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor           = System.Drawing.Color.White;
            this.ClientSize          = new System.Drawing.Size(380, 183);
            this.Controls.Add(this.lblIcono);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.lblMensaje);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.btnCancelar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.MinimizeBox     = false;
            this.Name            = "FormPassword";
            this.StartPosition   = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text            = "Acceso restringido";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label   lblIcono;
        private System.Windows.Forms.Label   lblTitulo;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label   lblMensaje;
        private System.Windows.Forms.Button  btnAceptar;
        private System.Windows.Forms.Button  btnCancelar;
    }
}
