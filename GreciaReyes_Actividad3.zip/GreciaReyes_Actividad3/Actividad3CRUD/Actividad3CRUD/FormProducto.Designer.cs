// ================================================
// FormProducto.Designer.cs
// ================================================
namespace Actividad3CRUD
{
    partial class FormProducto
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }

        private void InitializeComponent()
        {
            this.pnlHeader      = new System.Windows.Forms.Panel();
            this.lblTitulo      = new System.Windows.Forms.Label();
            this.grpDatos       = new System.Windows.Forms.GroupBox();
            this.lblCodigo      = new System.Windows.Forms.Label();
            this.txtCodigo      = new System.Windows.Forms.TextBox();
            this.lblNombre      = new System.Windows.Forms.Label();
            this.txtNombre      = new System.Windows.Forms.TextBox();
            this.lblPrecio      = new System.Windows.Forms.Label();
            this.txtPrecio      = new System.Windows.Forms.TextBox();
            this.lblNifProv     = new System.Windows.Forms.Label();
            this.txtNifProveedor= new System.Windows.Forms.TextBox();
            this.btnAgregar     = new System.Windows.Forms.Button();
            this.btnModificar   = new System.Windows.Forms.Button();
            this.btnEliminar    = new System.Windows.Forms.Button();
            this.btnMostrar     = new System.Windows.Forms.Button();
            this.btnRegresar    = new System.Windows.Forms.Button();
            this.dgvProductos   = new System.Windows.Forms.DataGridView();
            this.pnlHeader.SuspendLayout(); this.grpDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).BeginInit();
            this.SuspendLayout();

            // Panel header
            this.pnlHeader.BackColor = System.Drawing.Color.DarkOrange;
            this.pnlHeader.Controls.Add(this.lblTitulo); this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Name = "pnlHeader"; this.pnlHeader.Size = new System.Drawing.Size(820, 45); this.pnlHeader.TabIndex = 0;
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Fill; this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.White; this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Text = "REGISTRO PRODUCTO"; this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // GroupBox
            this.grpDatos.Controls.Add(this.lblCodigo); this.grpDatos.Controls.Add(this.txtCodigo);
            this.grpDatos.Controls.Add(this.lblNombre); this.grpDatos.Controls.Add(this.txtNombre);
            this.grpDatos.Controls.Add(this.lblPrecio); this.grpDatos.Controls.Add(this.txtPrecio);
            this.grpDatos.Controls.Add(this.lblNifProv); this.grpDatos.Controls.Add(this.txtNifProveedor);
            this.grpDatos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpDatos.Location = new System.Drawing.Point(15, 55); this.grpDatos.Name = "grpDatos";
            this.grpDatos.Size = new System.Drawing.Size(390, 165); this.grpDatos.TabIndex = 1; this.grpDatos.TabStop = false;
            this.grpDatos.Text = "Datos del producto:";

            // Código (solo lectura)
            this.lblCodigo.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblCodigo.Location = new System.Drawing.Point(10, 28); this.lblCodigo.Name = "lblCodigo"; this.lblCodigo.Size = new System.Drawing.Size(115, 22); this.lblCodigo.Text = "Código (ID):";
            this.txtCodigo.BackColor = System.Drawing.Color.LightGray; this.txtCodigo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtCodigo.Location = new System.Drawing.Point(130, 25); this.txtCodigo.Name = "txtCodigo"; this.txtCodigo.ReadOnly = true; this.txtCodigo.Size = new System.Drawing.Size(245, 23);

            // Nombre
            this.lblNombre.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblNombre.Location = new System.Drawing.Point(10, 63); this.lblNombre.Name = "lblNombre"; this.lblNombre.Size = new System.Drawing.Size(115, 22); this.lblNombre.Text = "Nombre:";
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 9F); this.txtNombre.Location = new System.Drawing.Point(130, 60);
            this.txtNombre.Name = "txtNombre"; this.txtNombre.Size = new System.Drawing.Size(245, 23);

            // Precio
            this.lblPrecio.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblPrecio.Location = new System.Drawing.Point(10, 98); this.lblPrecio.Name = "lblPrecio"; this.lblPrecio.Size = new System.Drawing.Size(115, 22); this.lblPrecio.Text = "Precio ($):";
            this.txtPrecio.Font = new System.Drawing.Font("Segoe UI", 9F); this.txtPrecio.Location = new System.Drawing.Point(130, 95);
            this.txtPrecio.Name = "txtPrecio"; this.txtPrecio.Size = new System.Drawing.Size(245, 23);

            // NIF Proveedor
            this.lblNifProv.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblNifProv.Location = new System.Drawing.Point(10, 133); this.lblNifProv.Name = "lblNifProv"; this.lblNifProv.Size = new System.Drawing.Size(115, 22); this.lblNifProv.Text = "ID Proveedor:";
            this.txtNifProveedor.Font = new System.Drawing.Font("Segoe UI", 9F); this.txtNifProveedor.Location = new System.Drawing.Point(130, 130);
            this.txtNifProveedor.Name = "txtNifProveedor"; this.txtNifProveedor.Size = new System.Drawing.Size(245, 23);

            // Botones
            this.btnAgregar.BackColor = System.Drawing.Color.DarkOrange; this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnAgregar.ForeColor = System.Drawing.Color.White;
            this.btnAgregar.Location = new System.Drawing.Point(420, 65); this.btnAgregar.Name = "btnAgregar"; this.btnAgregar.Size = new System.Drawing.Size(140, 35);
            this.btnAgregar.Text = "AGREGAR"; this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);

            this.btnModificar.BackColor = System.Drawing.Color.SeaGreen; this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnModificar.ForeColor = System.Drawing.Color.White;
            this.btnModificar.Location = new System.Drawing.Point(420, 110); this.btnModificar.Name = "btnModificar"; this.btnModificar.Size = new System.Drawing.Size(140, 35);
            this.btnModificar.Text = "MODIFICAR"; this.btnModificar.UseVisualStyleBackColor = false;
            this.btnModificar.Click += new System.EventHandler(this.BtnModificar_Click);

            this.btnEliminar.BackColor = System.Drawing.Color.Tomato; this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnEliminar.ForeColor = System.Drawing.Color.White;
            this.btnEliminar.Location = new System.Drawing.Point(570, 110); this.btnEliminar.Name = "btnEliminar"; this.btnEliminar.Size = new System.Drawing.Size(140, 35);
            this.btnEliminar.Text = "ELIMINAR"; this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);

            this.btnMostrar.BackColor = System.Drawing.Color.CornflowerBlue; this.btnMostrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMostrar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnMostrar.ForeColor = System.Drawing.Color.White;
            this.btnMostrar.Location = new System.Drawing.Point(420, 155); this.btnMostrar.Name = "btnMostrar"; this.btnMostrar.Size = new System.Drawing.Size(290, 35);
            this.btnMostrar.Text = "MOSTRAR"; this.btnMostrar.UseVisualStyleBackColor = false;
            this.btnMostrar.Click += new System.EventHandler(this.BtnMostrar_Click);

            this.btnRegresar.BackColor = System.Drawing.Color.SlateGray; this.btnRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegresar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnRegresar.ForeColor = System.Drawing.Color.White;
            this.btnRegresar.Location = new System.Drawing.Point(420, 200); this.btnRegresar.Name = "btnRegresar"; this.btnRegresar.Size = new System.Drawing.Size(140, 35);
            this.btnRegresar.Text = "REGRESAR"; this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);

            // Grid
            this.dgvProductos.AllowUserToAddRows = false; this.dgvProductos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProductos.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvProductos.Location = new System.Drawing.Point(15, 235); this.dgvProductos.Name = "dgvProductos";
            this.dgvProductos.ReadOnly = true; this.dgvProductos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProductos.Size = new System.Drawing.Size(775, 270); this.dgvProductos.TabIndex = 15;
            this.dgvProductos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvProductos_CellClick);

            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F); this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White; this.ClientSize = new System.Drawing.Size(820, 525);
            this.Controls.Add(this.dgvProductos); this.Controls.Add(this.btnRegresar); this.Controls.Add(this.btnMostrar);
            this.Controls.Add(this.btnEliminar); this.Controls.Add(this.btnModificar); this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.grpDatos); this.Controls.Add(this.pnlHeader);
            this.Name = "FormProducto"; this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent; this.Text = "Registro de Productos";
            this.pnlHeader.ResumeLayout(false); this.grpDatos.ResumeLayout(false); this.grpDatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).EndInit(); this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.GroupBox grpDatos;
        private System.Windows.Forms.Label lblCodigo;
        private System.Windows.Forms.TextBox txtCodigo;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.Label lblNifProv;
        private System.Windows.Forms.TextBox txtNifProveedor;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.DataGridView dgvProductos;
    }
}
