// ================================================
// FormProductosCaballeros.cs  
// ================================================
using System.Drawing;
using System.Windows.Forms;

namespace Actividad3CRUD
{
    public partial class FormProductosCaballeros : Form
    {
        public FormProductosCaballeros()
        {
            InitializeComponent();
            GenerarCheckBoxesTallas();
            CargarProductos();
        }

        private void GenerarCheckBoxesTallas()
        {
            string[] tallas = { "21", "21.5", "22", "22.5", "23", "23.5",
                                 "24", "24.5", "25", "25.5", "26", "26.5", "27" };
            int y = 22;
            foreach (string talla in tallas)
            {
                var cb = new CheckBox
                {
                    Text     = "Talla " + talla,
                    Location = new Point(10, y),
                    Size     = new System.Drawing.Size(170, 22),
                    Font     = new Font("Segoe UI", 9F)
                };
                grpTallas.Controls.Add(cb);
                y += 28;
            }
        }

        private void CargarProductos()
        {
            string[][] productos = {
                new[]{"Zapato formal negro",       "$650.00", "Formales"},
                new[]{"Zapato formal café",        "$650.00", "Formales"},
                new[]{"Zapato casual gris",        "$520.00", "Casuales"},
                new[]{"Mocasín café piel",         "$750.00", "Mocasines"},
                new[]{"Mocasín negro clásico",     "$720.00", "Mocasines"},
                new[]{"Bota de trabajo café",      "$950.00", "Botas"},
                new[]{"Bota casual negra",         "$880.00", "Botas"},
                new[]{"Tenis deportivo blanco",    "$680.00", "Tenis"},
                new[]{"Tenis running azul",        "$790.00", "Tenis"},
                new[]{"Sandalia casual verano",    "$350.00", "Sandalias"},
                new[]{"Huarache artesanal",        "$420.00", "Artesanales"},
                new[]{"Oxford clásico negro",      "$700.00", "Oxford"},
            };
            foreach (var p in productos)
            {
                var item = new ListViewItem(p[0]);
                item.SubItems.Add(p[1]);
                item.SubItems.Add(p[2]);
                lvProductos.Items.Add(item);
            }
        }

        private void BtnCerrar_Click(object sender, System.EventArgs e) => this.Close();
    }
}
