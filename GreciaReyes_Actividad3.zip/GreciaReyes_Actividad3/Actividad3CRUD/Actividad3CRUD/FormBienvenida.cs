// ================================================
// FormBienvenida.cs
// ================================================
using System.Drawing;
using System.Windows.Forms;

namespace Actividad3CRUD
{
    public partial class FormBienvenida : Form
    {
        public FormBienvenida(string titulo, string mensaje)
        {
            InitializeComponent();
            this.Text         = titulo;
            lblHeader.Text    = titulo;
            rtbMensaje.Text   = mensaje;
        }

        private void BtnCerrar_Click(object sender, System.EventArgs e) => this.Close();
    }
}
