// ================================================
// FormBienvenida.Designer.cs
// ================================================
namespace Actividad3CRUD
{
    partial class FormBienvenida
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }

        private void InitializeComponent()
        {
            this.pnlHeader  = new System.Windows.Forms.Panel();
            this.lblHeader  = new System.Windows.Forms.Label();
            this.rtbMensaje = new System.Windows.Forms.RichTextBox();
            this.btnCerrar  = new System.Windows.Forms.Button();
            this.pnlHeader.SuspendLayout();
            this.SuspendLayout();

            // pnlHeader
            this.pnlHeader.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlHeader.Controls.Add(this.lblHeader);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Name = "pnlHeader"; this.pnlHeader.Size = new System.Drawing.Size(500, 50); this.pnlHeader.TabIndex = 0;

            // lblHeader
            this.lblHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.White; this.lblHeader.Name = "lblHeader";
            this.lblHeader.Text = ""; this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // rtbMensaje
            this.rtbMensaje.BackColor = System.Drawing.Color.White;
            this.rtbMensaje.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbMensaje.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.rtbMensaje.Location = new System.Drawing.Point(20, 60); this.rtbMensaje.Name = "rtbMensaje";
            this.rtbMensaje.ReadOnly = true; this.rtbMensaje.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbMensaje.Size = new System.Drawing.Size(460, 185); this.rtbMensaje.TabIndex = 1; this.rtbMensaje.Text = "";

            // btnCerrar
            this.btnCerrar.BackColor = System.Drawing.Color.SteelBlue;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnCerrar.ForeColor = System.Drawing.Color.White;
            this.btnCerrar.Location = new System.Drawing.Point(195, 258); this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(110, 35); this.btnCerrar.TabIndex = 2; this.btnCerrar.Text = "Cerrar";
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.BtnCerrar_Click);

            // FormBienvenida
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F); this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White; this.ClientSize = new System.Drawing.Size(500, 310);
            this.Controls.Add(this.pnlHeader); this.Controls.Add(this.rtbMensaje); this.Controls.Add(this.btnCerrar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false; this.Name = "FormBienvenida";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent; this.Text = "Bienvenida";
            this.pnlHeader.ResumeLayout(false); this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.RichTextBox rtbMensaje;
        private System.Windows.Forms.Button btnCerrar;
    }
}
