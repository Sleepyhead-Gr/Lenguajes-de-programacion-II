// ================================================
// FormProductosDamas.cs 
// ================================================
using System.Drawing;
using System.Windows.Forms;

namespace Actividad3CRUD
{
    public partial class FormProductosDamas : Form
    {
        public FormProductosDamas()
        {
            InitializeComponent();
            GenerarCheckBoxesTallas();
            CargarProductos();
        }

        private void GenerarCheckBoxesTallas()
        {
            string[] tallas = { "21", "21.5", "22", "22.5", "23", "23.5",
                                 "24", "24.5", "25", "25.5", "26", "26.5", "27" };
            int y = 22;
            foreach (string talla in tallas)
            {
                var cb = new CheckBox
                {
                    Text     = "Talla " + talla,
                    Location = new Point(10, y),
                    Size     = new System.Drawing.Size(170, 22),
                    Font     = new Font("Segoe UI", 9F)
                };
                grpTallas.Controls.Add(cb);
                y += 28;
            }
        }

        private void CargarProductos()
        {
            string[][] productos = {
                new[]{"Sandalia de tacón",        "$450.00", "Sandalias"},
                new[]{"Sandalia plana casual",     "$320.00", "Sandalias"},
                new[]{"Bota de cuero café",        "$890.00", "Botas"},
                new[]{"Bota corta negra",          "$750.00", "Botas"},
                new[]{"Ballerina clásica negra",   "$380.00", "Ballerinas"},
                new[]{"Ballerina estampada",       "$400.00", "Ballerinas"},
                new[]{"Zapato formal negro",       "$560.00", "Formales"},
                new[]{"Zapato formal café",        "$560.00", "Formales"},
                new[]{"Tenis casual blanco",       "$620.00", "Tenis"},
                new[]{"Tenis deportivo rosa",      "$700.00", "Tenis"},
                new[]{"Mocasín dama café",         "$490.00", "Mocasines"},
                new[]{"Plataforma moda",           "$670.00", "Plataformas"},
            };
            foreach (var p in productos)
            {
                var item = new ListViewItem(p[0]);
                item.SubItems.Add(p[1]);
                item.SubItems.Add(p[2]);
                lvProductos.Items.Add(item);
            }
        }

        private void BtnCerrar_Click(object sender, System.EventArgs e) => this.Close();
    }
}
