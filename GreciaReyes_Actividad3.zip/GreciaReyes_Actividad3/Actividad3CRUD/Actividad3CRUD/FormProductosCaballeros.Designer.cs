// ================================================
// FormProductosCaballeros.Designer.cs
// ================================================
namespace Actividad3CRUD
{
    partial class FormProductosCaballeros
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }

        private void InitializeComponent()
        {
            this.pnlHeader    = new System.Windows.Forms.Panel();
            this.lblTitulo    = new System.Windows.Forms.Label();
            this.grpTallas    = new System.Windows.Forms.GroupBox();
            this.grpProductos = new System.Windows.Forms.GroupBox();
            this.lvProductos  = new System.Windows.Forms.ListView();
            this.colNombre    = new System.Windows.Forms.ColumnHeader();
            this.colPrecio    = new System.Windows.Forms.ColumnHeader();
            this.colCategoria = new System.Windows.Forms.ColumnHeader();
            this.btnCerrar    = new System.Windows.Forms.Button();
            this.pnlHeader.SuspendLayout();
            this.grpProductos.SuspendLayout();
            this.SuspendLayout();

            // Header
            this.pnlHeader.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlHeader.Controls.Add(this.lblTitulo);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Name = "pnlHeader"; this.pnlHeader.Size = new System.Drawing.Size(780, 50); this.pnlHeader.TabIndex = 0;

            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.White; this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Text = "👞  Catálogo Caballeros  👞";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // grpTallas (CheckBoxes se generan en .cs)
            this.grpTallas.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpTallas.Location = new System.Drawing.Point(15, 60); this.grpTallas.Name = "grpTallas";
            this.grpTallas.Size = new System.Drawing.Size(200, 460); this.grpTallas.TabIndex = 1;
            this.grpTallas.TabStop = false; this.grpTallas.Text = "Selecciona tu talla";

            // grpProductos
            this.grpProductos.Controls.Add(this.lvProductos);
            this.grpProductos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpProductos.Location = new System.Drawing.Point(228, 60); this.grpProductos.Name = "grpProductos";
            this.grpProductos.Size = new System.Drawing.Size(535, 460); this.grpProductos.TabIndex = 2;
            this.grpProductos.TabStop = false; this.grpProductos.Text = "Productos Disponibles – Caballeros";

            // ListView
            this.lvProductos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { this.colNombre, this.colPrecio, this.colCategoria });
            this.lvProductos.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lvProductos.FullRowSelect = true; this.lvProductos.GridLines = true;
            this.lvProductos.Location = new System.Drawing.Point(10, 22); this.lvProductos.Name = "lvProductos";
            this.lvProductos.Size = new System.Drawing.Size(510, 420); this.lvProductos.TabIndex = 0;
            this.lvProductos.View = System.Windows.Forms.View.Details;
            this.colNombre.Text = "Producto"; this.colNombre.Width = 220;
            this.colPrecio.Text = "Precio"; this.colPrecio.Width = 90;
            this.colCategoria.Text = "Categoría"; this.colCategoria.Width = 150;

            // Botón
            this.btnCerrar.BackColor = System.Drawing.Color.SteelBlue;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrar.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnCerrar.ForeColor = System.Drawing.Color.White;
            this.btnCerrar.Location = new System.Drawing.Point(310, 535); this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(120, 35); this.btnCerrar.TabIndex = 3; this.btnCerrar.Text = "Regresar";
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.BtnCerrar_Click);

            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F); this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White; this.ClientSize = new System.Drawing.Size(780, 590);
            this.Controls.Add(this.btnCerrar); this.Controls.Add(this.grpProductos);
            this.Controls.Add(this.grpTallas); this.Controls.Add(this.pnlHeader);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false; this.Name = "FormProductosCaballeros";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent; this.Text = "Catálogo – Caballeros";
            this.pnlHeader.ResumeLayout(false); this.grpProductos.ResumeLayout(false); this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.GroupBox grpTallas;
        private System.Windows.Forms.GroupBox grpProductos;
        private System.Windows.Forms.ListView lvProductos;
        private System.Windows.Forms.ColumnHeader colNombre;
        private System.Windows.Forms.ColumnHeader colPrecio;
        private System.Windows.Forms.ColumnHeader colCategoria;
        private System.Windows.Forms.Button btnCerrar;
    }
}
