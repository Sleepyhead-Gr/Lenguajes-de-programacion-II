// ================================================
// FormCompras.Designer.cs
// ================================================
namespace Actividad3CRUD
{
    partial class FormCompras
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing) { if (disposing && components != null) components.Dispose(); base.Dispose(disposing); }

        private void InitializeComponent()
        {
            this.pnlHeader    = new System.Windows.Forms.Panel();
            this.lblTitulo    = new System.Windows.Forms.Label();
            this.grpDatos     = new System.Windows.Forms.GroupBox();
            this.lblId        = new System.Windows.Forms.Label();
            this.txtId        = new System.Windows.Forms.TextBox();
            this.lblCliente   = new System.Windows.Forms.Label();
            this.cmbClientes  = new System.Windows.Forms.ComboBox();
            this.lblProducto  = new System.Windows.Forms.Label();
            this.cmbProductos = new System.Windows.Forms.ComboBox();
            this.lblFecha     = new System.Windows.Forms.Label();
            this.txtFecha     = new System.Windows.Forms.TextBox();
            this.btnAgregar   = new System.Windows.Forms.Button();
            this.btnModificar = new System.Windows.Forms.Button();
            this.btnEliminar  = new System.Windows.Forms.Button();
            this.btnMostrar   = new System.Windows.Forms.Button();
            this.btnRegresar  = new System.Windows.Forms.Button();
            this.dgvCompras   = new System.Windows.Forms.DataGridView();
            this.pnlHeader.SuspendLayout(); this.grpDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompras)).BeginInit();
            this.SuspendLayout();

            // Header
            this.pnlHeader.BackColor = System.Drawing.Color.Teal;
            this.pnlHeader.Controls.Add(this.lblTitulo); this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Name = "pnlHeader"; this.pnlHeader.Size = new System.Drawing.Size(870, 45); this.pnlHeader.TabIndex = 0;
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Fill; this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.White; this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Text = "REGISTRO DE COMPRAS"; this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // GroupBox
            this.grpDatos.Controls.Add(this.lblId); this.grpDatos.Controls.Add(this.txtId);
            this.grpDatos.Controls.Add(this.lblCliente); this.grpDatos.Controls.Add(this.cmbClientes);
            this.grpDatos.Controls.Add(this.lblProducto); this.grpDatos.Controls.Add(this.cmbProductos);
            this.grpDatos.Controls.Add(this.lblFecha); this.grpDatos.Controls.Add(this.txtFecha);
            this.grpDatos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpDatos.Location = new System.Drawing.Point(15, 55); this.grpDatos.Name = "grpDatos";
            this.grpDatos.Size = new System.Drawing.Size(490, 195); this.grpDatos.TabIndex = 1; this.grpDatos.TabStop = false;
            this.grpDatos.Text = "Datos de la compra:";

            // ID
            this.lblId.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblId.Location = new System.Drawing.Point(10, 28); this.lblId.Name = "lblId"; this.lblId.Size = new System.Drawing.Size(125, 22); this.lblId.Text = "ID Compra:";
            this.txtId.BackColor = System.Drawing.Color.LightGray; this.txtId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtId.Location = new System.Drawing.Point(140, 25); this.txtId.Name = "txtId"; this.txtId.ReadOnly = true; this.txtId.Size = new System.Drawing.Size(150, 23);

            // Cliente
            this.lblCliente.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblCliente.Location = new System.Drawing.Point(10, 63); this.lblCliente.Name = "lblCliente"; this.lblCliente.Size = new System.Drawing.Size(125, 22); this.lblCliente.Text = "Cliente:";
            this.cmbClientes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList; this.cmbClientes.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cmbClientes.Location = new System.Drawing.Point(140, 60); this.cmbClientes.Name = "cmbClientes"; this.cmbClientes.Size = new System.Drawing.Size(335, 23);

            // Producto
            this.lblProducto.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblProducto.Location = new System.Drawing.Point(10, 100); this.lblProducto.Name = "lblProducto"; this.lblProducto.Size = new System.Drawing.Size(125, 22); this.lblProducto.Text = "Producto:";
            this.cmbProductos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList; this.cmbProductos.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cmbProductos.Location = new System.Drawing.Point(140, 97); this.cmbProductos.Name = "cmbProductos"; this.cmbProductos.Size = new System.Drawing.Size(335, 23);

            // Fecha
            this.lblFecha.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblFecha.Location = new System.Drawing.Point(10, 138); this.lblFecha.Name = "lblFecha"; this.lblFecha.Size = new System.Drawing.Size(125, 22); this.lblFecha.Text = "Fecha Compra:";
            this.txtFecha.Font = new System.Drawing.Font("Segoe UI", 9F); this.txtFecha.Location = new System.Drawing.Point(140, 135);
            this.txtFecha.Name = "txtFecha"; this.txtFecha.Size = new System.Drawing.Size(150, 23); this.txtFecha.Text = System.DateTime.Now.ToString("yyyy-MM-dd");

            // Botones
            this.btnAgregar.BackColor = System.Drawing.Color.Teal; this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnAgregar.ForeColor = System.Drawing.Color.White;
            this.btnAgregar.Location = new System.Drawing.Point(525, 65); this.btnAgregar.Name = "btnAgregar"; this.btnAgregar.Size = new System.Drawing.Size(140, 35);
            this.btnAgregar.Text = "AGREGAR"; this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);

            this.btnModificar.BackColor = System.Drawing.Color.SeaGreen; this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnModificar.ForeColor = System.Drawing.Color.White;
            this.btnModificar.Location = new System.Drawing.Point(525, 110); this.btnModificar.Name = "btnModificar"; this.btnModificar.Size = new System.Drawing.Size(140, 35);
            this.btnModificar.Text = "MODIFICAR"; this.btnModificar.UseVisualStyleBackColor = false;
            this.btnModificar.Click += new System.EventHandler(this.BtnModificar_Click);

            this.btnEliminar.BackColor = System.Drawing.Color.Tomato; this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnEliminar.ForeColor = System.Drawing.Color.White;
            this.btnEliminar.Location = new System.Drawing.Point(675, 110); this.btnEliminar.Name = "btnEliminar"; this.btnEliminar.Size = new System.Drawing.Size(140, 35);
            this.btnEliminar.Text = "ELIMINAR"; this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);

            this.btnMostrar.BackColor = System.Drawing.Color.CornflowerBlue; this.btnMostrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMostrar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnMostrar.ForeColor = System.Drawing.Color.White;
            this.btnMostrar.Location = new System.Drawing.Point(525, 155); this.btnMostrar.Name = "btnMostrar"; this.btnMostrar.Size = new System.Drawing.Size(290, 35);
            this.btnMostrar.Text = "MOSTRAR"; this.btnMostrar.UseVisualStyleBackColor = false;
            this.btnMostrar.Click += new System.EventHandler(this.BtnMostrar_Click);

            this.btnRegresar.BackColor = System.Drawing.Color.SlateGray; this.btnRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegresar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnRegresar.ForeColor = System.Drawing.Color.White;
            this.btnRegresar.Location = new System.Drawing.Point(525, 200); this.btnRegresar.Name = "btnRegresar"; this.btnRegresar.Size = new System.Drawing.Size(140, 35);
            this.btnRegresar.Text = "REGRESAR"; this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);

            // Grid
            this.dgvCompras.AllowUserToAddRows = false; this.dgvCompras.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCompras.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvCompras.Location = new System.Drawing.Point(15, 265); this.dgvCompras.Name = "dgvCompras";
            this.dgvCompras.ReadOnly = true; this.dgvCompras.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCompras.Size = new System.Drawing.Size(835, 270); this.dgvCompras.TabIndex = 15;
            this.dgvCompras.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvCompras_CellClick);

            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F); this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White; this.ClientSize = new System.Drawing.Size(870, 555);
            this.Controls.Add(this.dgvCompras); this.Controls.Add(this.btnRegresar); this.Controls.Add(this.btnMostrar);
            this.Controls.Add(this.btnEliminar); this.Controls.Add(this.btnModificar); this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.grpDatos); this.Controls.Add(this.pnlHeader);
            this.Name = "FormCompras"; this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent; this.Text = "Registro de Compras";
            this.pnlHeader.ResumeLayout(false); this.grpDatos.ResumeLayout(false); this.grpDatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCompras)).EndInit(); this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.GroupBox grpDatos;
        private System.Windows.Forms.Label lblId;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label lblCliente;
        private System.Windows.Forms.ComboBox cmbClientes;
        private System.Windows.Forms.Label lblProducto;
        private System.Windows.Forms.ComboBox cmbProductos;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.TextBox txtFecha;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.DataGridView dgvCompras;
    }
}
