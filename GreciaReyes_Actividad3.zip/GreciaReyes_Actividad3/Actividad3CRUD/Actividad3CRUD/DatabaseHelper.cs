
using System.Data.SqlClient;

namespace Actividad3CRUD
{
    public static class DatabaseHelper
    {
        // *** MODIFICA ESTA CADENA DE CONEXIÓN ***
        private static readonly string connectionString =
            "Server=localhost\\SQLEXPRESS;Database=ZapateriaCRUD;Integrated Security=True;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
