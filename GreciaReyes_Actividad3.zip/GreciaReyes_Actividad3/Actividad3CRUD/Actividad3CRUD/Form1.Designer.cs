// ================================================
// Form1.Designer
// ================================================
namespace Actividad3CRUD
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.menuStrip1             = new System.Windows.Forms.MenuStrip();
            this.mnuBienvenida          = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMensajeBienvenida   = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuQuienesSomos        = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMision              = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuVision              = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuProductos           = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDamas               = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCaballeros          = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuRegistro            = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCliente             = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuProveedor           = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuProductoReg         = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCompras             = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuSalir               = new System.Windows.Forms.ToolStripMenuItem();
            this.lblCentro              = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();

            // ── menuStrip1 ──────────────────────────────
            this.menuStrip1.BackColor = System.Drawing.Color.SteelBlue;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuBienvenida, this.mnuProductos, this.mnuRegistro,
                this.mnuCompras, this.mnuSalir });
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name     = "menuStrip1";
            this.menuStrip1.Size     = new System.Drawing.Size(900, 24);
            this.menuStrip1.TabIndex = 0;

            // ── mnuBienvenida ───────────────────────────
            this.mnuBienvenida.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuMensajeBienvenida, this.mnuQuienesSomos,
                this.mnuMision, this.mnuVision });
            this.mnuBienvenida.ForeColor = System.Drawing.Color.White;
            this.mnuBienvenida.Name      = "mnuBienvenida";
            this.mnuBienvenida.Size      = new System.Drawing.Size(80, 20);
            this.mnuBienvenida.Text      = "Bienvenida";

            this.mnuMensajeBienvenida.Name   = "mnuMensajeBienvenida";
            this.mnuMensajeBienvenida.Size   = new System.Drawing.Size(210, 22);
            this.mnuMensajeBienvenida.Text   = "Mensaje de Bienvenida";
            this.mnuMensajeBienvenida.Click += new System.EventHandler(this.MnuMensajeBienvenida_Click);

            this.mnuQuienesSomos.Name   = "mnuQuienesSomos";
            this.mnuQuienesSomos.Size   = new System.Drawing.Size(210, 22);
            this.mnuQuienesSomos.Text   = "¿Quiénes Somos?";
            this.mnuQuienesSomos.Click += new System.EventHandler(this.MnuQuienesSomos_Click);

            this.mnuMision.Name   = "mnuMision";
            this.mnuMision.Size   = new System.Drawing.Size(210, 22);
            this.mnuMision.Text   = "Misión";
            this.mnuMision.Click += new System.EventHandler(this.MnuMision_Click);

            this.mnuVision.Name   = "mnuVision";
            this.mnuVision.Size   = new System.Drawing.Size(210, 22);
            this.mnuVision.Text   = "Visión";
            this.mnuVision.Click += new System.EventHandler(this.MnuVision_Click);

            // ── mnuProductos ────────────────────────────
            this.mnuProductos.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuDamas, this.mnuCaballeros });
            this.mnuProductos.ForeColor = System.Drawing.Color.White;
            this.mnuProductos.Name      = "mnuProductos";
            this.mnuProductos.Size      = new System.Drawing.Size(70, 20);
            this.mnuProductos.Text      = "Productos";

            this.mnuDamas.Name   = "mnuDamas";
            this.mnuDamas.Size   = new System.Drawing.Size(130, 22);
            this.mnuDamas.Text   = "Damas";
            this.mnuDamas.Click += new System.EventHandler(this.MnuDamas_Click);

            this.mnuCaballeros.Name   = "mnuCaballeros";
            this.mnuCaballeros.Size   = new System.Drawing.Size(130, 22);
            this.mnuCaballeros.Text   = "Caballeros";
            this.mnuCaballeros.Click += new System.EventHandler(this.MnuCaballeros_Click);

            // ── mnuRegistro ─────────────────────────────
            this.mnuRegistro.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.mnuCliente, this.mnuProveedor, this.mnuProductoReg });
            this.mnuRegistro.ForeColor = System.Drawing.Color.White;
            this.mnuRegistro.Name      = "mnuRegistro";
            this.mnuRegistro.Size      = new System.Drawing.Size(68, 20);
            this.mnuRegistro.Text      = "Registro";

            this.mnuCliente.Name   = "mnuCliente";
            this.mnuCliente.Size   = new System.Drawing.Size(130, 22);
            this.mnuCliente.Text   = "Cliente";
            this.mnuCliente.Click += new System.EventHandler(this.MnuCliente_Click);

            this.mnuProveedor.Name   = "mnuProveedor";
            this.mnuProveedor.Size   = new System.Drawing.Size(130, 22);
            this.mnuProveedor.Text   = "Proveedor";
            this.mnuProveedor.Click += new System.EventHandler(this.MnuProveedor_Click);

            this.mnuProductoReg.Name   = "mnuProductoReg";
            this.mnuProductoReg.Size   = new System.Drawing.Size(130, 22);
            this.mnuProductoReg.Text   = "Producto";
            this.mnuProductoReg.Click += new System.EventHandler(this.MnuProductoReg_Click);

            // ── mnuCompras ──────────────────────────────
            this.mnuCompras.ForeColor = System.Drawing.Color.White;
            this.mnuCompras.Name      = "mnuCompras";
            this.mnuCompras.Size      = new System.Drawing.Size(62, 20);
            this.mnuCompras.Text      = "Compras";
            this.mnuCompras.Click    += new System.EventHandler(this.MnuCompras_Click);

            // ── mnuSalir ────────────────────────────────
            this.mnuSalir.ForeColor = System.Drawing.Color.Yellow;
            this.mnuSalir.Name      = "mnuSalir";
            this.mnuSalir.Size      = new System.Drawing.Size(46, 20);
            this.mnuSalir.Text      = "Salir";
            this.mnuSalir.Click    += new System.EventHandler(this.MnuSalir_Click);

            // ── lblCentro ───────────────────────────────
            this.lblCentro.Dock      = System.Windows.Forms.DockStyle.Fill;
            this.lblCentro.Font      = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblCentro.ForeColor = System.Drawing.Color.DimGray;
            this.lblCentro.Location  = new System.Drawing.Point(0, 24);
            this.lblCentro.Name      = "lblCentro";
            this.lblCentro.Size      = new System.Drawing.Size(900, 576);
            this.lblCentro.TabIndex  = 1;
            this.lblCentro.Text      = "Bienvenido al Sistema de Zapatería UMI\r\nUtiliza el menú superior para navegar.";
            this.lblCentro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // ── Form1 ───────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor           = System.Drawing.Color.WhiteSmoke;
            this.ClientSize          = new System.Drawing.Size(900, 600);
            this.Controls.Add(this.lblCentro);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip       = this.menuStrip1;
            this.Name                = "Form1";
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text                = "Actividad 3: CRUD – Zapatería UMI";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // ── Declaraciones ───────────────────────────────
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuBienvenida;
        private System.Windows.Forms.ToolStripMenuItem mnuMensajeBienvenida;
        private System.Windows.Forms.ToolStripMenuItem mnuQuienesSomos;
        private System.Windows.Forms.ToolStripMenuItem mnuMision;
        private System.Windows.Forms.ToolStripMenuItem mnuVision;
        private System.Windows.Forms.ToolStripMenuItem mnuProductos;
        private System.Windows.Forms.ToolStripMenuItem mnuDamas;
        private System.Windows.Forms.ToolStripMenuItem mnuCaballeros;
        private System.Windows.Forms.ToolStripMenuItem mnuRegistro;
        private System.Windows.Forms.ToolStripMenuItem mnuCliente;
        private System.Windows.Forms.ToolStripMenuItem mnuProveedor;
        private System.Windows.Forms.ToolStripMenuItem mnuProductoReg;
        private System.Windows.Forms.ToolStripMenuItem mnuCompras;
        private System.Windows.Forms.ToolStripMenuItem mnuSalir;
        private System.Windows.Forms.Label lblCentro;
    }
}
