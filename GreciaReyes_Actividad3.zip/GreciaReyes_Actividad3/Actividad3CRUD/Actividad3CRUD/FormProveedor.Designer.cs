// ================================================
// FormProveedor.Designer.cs
// ================================================
namespace Actividad3CRUD
{
    partial class FormProveedor
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.pnlHeader      = new System.Windows.Forms.Panel();
            this.lblTitulo      = new System.Windows.Forms.Label();
            this.grpDatos       = new System.Windows.Forms.GroupBox();
            this.lblNif         = new System.Windows.Forms.Label();
            this.txtNif         = new System.Windows.Forms.TextBox();
            this.lblNombre      = new System.Windows.Forms.Label();
            this.txtNombre      = new System.Windows.Forms.TextBox();
            this.lblDireccion   = new System.Windows.Forms.Label();
            this.txtDireccion   = new System.Windows.Forms.TextBox();
            this.btnAgregar     = new System.Windows.Forms.Button();
            this.btnModificar   = new System.Windows.Forms.Button();
            this.btnEliminar    = new System.Windows.Forms.Button();
            this.btnMostrar     = new System.Windows.Forms.Button();
            this.btnRegresar    = new System.Windows.Forms.Button();
            this.dgvProveedores = new System.Windows.Forms.DataGridView();
            this.pnlHeader.SuspendLayout();
            this.grpDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProveedores)).BeginInit();
            this.SuspendLayout();

            // pnlHeader
            this.pnlHeader.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.pnlHeader.Controls.Add(this.lblTitulo);
            this.pnlHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHeader.Name = "pnlHeader"; this.pnlHeader.Size = new System.Drawing.Size(820, 45); this.pnlHeader.TabIndex = 0;

            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTitulo.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Name = "lblTitulo"; this.lblTitulo.Text = "REGISTRO PROVEEDOR";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // grpDatos
            this.grpDatos.Controls.Add(this.lblNif); this.grpDatos.Controls.Add(this.txtNif);
            this.grpDatos.Controls.Add(this.lblNombre); this.grpDatos.Controls.Add(this.txtNombre);
            this.grpDatos.Controls.Add(this.lblDireccion); this.grpDatos.Controls.Add(this.txtDireccion);
            this.grpDatos.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpDatos.Location = new System.Drawing.Point(15, 55); this.grpDatos.Name = "grpDatos";
            this.grpDatos.Size = new System.Drawing.Size(390, 150); this.grpDatos.TabIndex = 1; this.grpDatos.TabStop = false;
            this.grpDatos.Text = "Datos del proveedor:";

            // NIF (solo lectura)
            this.lblNif.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblNif.Location = new System.Drawing.Point(10, 28); this.lblNif.Name = "lblNif";
            this.lblNif.Size = new System.Drawing.Size(115, 22); this.lblNif.TabIndex = 0; this.lblNif.Text = "NIF (ID):";
            this.txtNif.BackColor = System.Drawing.Color.LightGray;
            this.txtNif.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNif.Location = new System.Drawing.Point(130, 25); this.txtNif.Name = "txtNif";
            this.txtNif.ReadOnly = true; this.txtNif.Size = new System.Drawing.Size(245, 23); this.txtNif.TabIndex = 1;

            // Nombre
            this.lblNombre.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblNombre.Location = new System.Drawing.Point(10, 63); this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(115, 22); this.lblNombre.TabIndex = 2; this.lblNombre.Text = "Nombre:";
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtNombre.Location = new System.Drawing.Point(130, 60); this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(245, 23); this.txtNombre.TabIndex = 3;

            // Dirección
            this.lblDireccion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular);
            this.lblDireccion.Location = new System.Drawing.Point(10, 98); this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(115, 22); this.lblDireccion.TabIndex = 4; this.lblDireccion.Text = "Dirección:";
            this.txtDireccion.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtDireccion.Location = new System.Drawing.Point(130, 95); this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(245, 23); this.txtDireccion.TabIndex = 5;

            // Botones
            this.btnAgregar.BackColor = System.Drawing.Color.CornflowerBlue; this.btnAgregar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgregar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnAgregar.ForeColor = System.Drawing.Color.White;
            this.btnAgregar.Location = new System.Drawing.Point(420, 65); this.btnAgregar.Name = "btnAgregar"; this.btnAgregar.Size = new System.Drawing.Size(140, 35);
            this.btnAgregar.TabIndex = 10; this.btnAgregar.Text = "AGREGAR"; this.btnAgregar.UseVisualStyleBackColor = false;
            this.btnAgregar.Click += new System.EventHandler(this.BtnAgregar_Click);

            this.btnModificar.BackColor = System.Drawing.Color.SeaGreen; this.btnModificar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnModificar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnModificar.ForeColor = System.Drawing.Color.White;
            this.btnModificar.Location = new System.Drawing.Point(420, 110); this.btnModificar.Name = "btnModificar"; this.btnModificar.Size = new System.Drawing.Size(140, 35);
            this.btnModificar.TabIndex = 11; this.btnModificar.Text = "MODIFICAR"; this.btnModificar.UseVisualStyleBackColor = false;
            this.btnModificar.Click += new System.EventHandler(this.BtnModificar_Click);

            this.btnEliminar.BackColor = System.Drawing.Color.Tomato; this.btnEliminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnEliminar.ForeColor = System.Drawing.Color.White;
            this.btnEliminar.Location = new System.Drawing.Point(570, 110); this.btnEliminar.Name = "btnEliminar"; this.btnEliminar.Size = new System.Drawing.Size(140, 35);
            this.btnEliminar.TabIndex = 12; this.btnEliminar.Text = "ELIMINAR"; this.btnEliminar.UseVisualStyleBackColor = false;
            this.btnEliminar.Click += new System.EventHandler(this.BtnEliminar_Click);

            this.btnMostrar.BackColor = System.Drawing.Color.CornflowerBlue; this.btnMostrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMostrar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnMostrar.ForeColor = System.Drawing.Color.White;
            this.btnMostrar.Location = new System.Drawing.Point(420, 155); this.btnMostrar.Name = "btnMostrar"; this.btnMostrar.Size = new System.Drawing.Size(290, 35);
            this.btnMostrar.TabIndex = 13; this.btnMostrar.Text = "MOSTRAR"; this.btnMostrar.UseVisualStyleBackColor = false;
            this.btnMostrar.Click += new System.EventHandler(this.BtnMostrar_Click);

            this.btnRegresar.BackColor = System.Drawing.Color.SlateGray; this.btnRegresar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRegresar.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold); this.btnRegresar.ForeColor = System.Drawing.Color.White;
            this.btnRegresar.Location = new System.Drawing.Point(420, 200); this.btnRegresar.Name = "btnRegresar"; this.btnRegresar.Size = new System.Drawing.Size(140, 35);
            this.btnRegresar.TabIndex = 14; this.btnRegresar.Text = "REGRESAR"; this.btnRegresar.UseVisualStyleBackColor = false;
            this.btnRegresar.Click += new System.EventHandler(this.BtnRegresar_Click);

            // dgvProveedores
            this.dgvProveedores.AllowUserToAddRows = false; this.dgvProveedores.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvProveedores.BackgroundColor = System.Drawing.Color.WhiteSmoke;
            this.dgvProveedores.Location = new System.Drawing.Point(15, 220); this.dgvProveedores.Name = "dgvProveedores";
            this.dgvProveedores.ReadOnly = true; this.dgvProveedores.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProveedores.Size = new System.Drawing.Size(775, 255); this.dgvProveedores.TabIndex = 15;
            this.dgvProveedores.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvProveedores_CellClick);

            // Form
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F); this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White; this.ClientSize = new System.Drawing.Size(820, 495);
            this.Controls.Add(this.dgvProveedores); this.Controls.Add(this.btnRegresar); this.Controls.Add(this.btnMostrar);
            this.Controls.Add(this.btnEliminar); this.Controls.Add(this.btnModificar); this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.grpDatos); this.Controls.Add(this.pnlHeader);
            this.Name = "FormProveedor"; this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Registro de Proveedores";
            this.pnlHeader.ResumeLayout(false); this.grpDatos.ResumeLayout(false); this.grpDatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProveedores)).EndInit(); this.ResumeLayout(false);
        }

        private System.Windows.Forms.Panel pnlHeader;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.GroupBox grpDatos;
        private System.Windows.Forms.Label lblNif;
        private System.Windows.Forms.TextBox txtNif;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Button btnModificar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Button btnRegresar;
        private System.Windows.Forms.DataGridView dgvProveedores;
    }
}
